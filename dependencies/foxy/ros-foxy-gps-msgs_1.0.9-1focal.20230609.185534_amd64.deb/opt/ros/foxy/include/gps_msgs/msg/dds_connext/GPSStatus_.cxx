

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from GPSStatus_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#ifndef dds_c_log_impl_h              
#include "dds_c/dds_c_log_impl.h"                                
#endif        

#ifndef cdr_type_h
#include "cdr/cdr_type.h"
#endif    

#ifndef osapi_heap_h
#include "osapi/osapi_heap.h" 
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "GPSStatus_.h"

#include <new>

namespace gps_msgs {
    namespace msg {
        namespace dds_ {
            namespace GPSStatus_Constants {
            } /* namespace GPSStatus_Constants  */

            /* ========================================================================= */
            const char *GPSStatus_TYPENAME = "gps_msgs::msg::dds_::GPSStatus_";

            DDS_TypeCode* GPSStatus__get_typecode()
            {
                static RTIBool is_initialized = RTI_FALSE;

                static DDS_TypeCode GPSStatus__g_tc_satellite_used_prn__sequence = DDS_INITIALIZE_SEQUENCE_TYPECODE(RTI_INT32_MAX,NULL);
                static DDS_TypeCode GPSStatus__g_tc_satellite_visible_prn__sequence = DDS_INITIALIZE_SEQUENCE_TYPECODE(RTI_INT32_MAX,NULL);
                static DDS_TypeCode GPSStatus__g_tc_satellite_visible_z__sequence = DDS_INITIALIZE_SEQUENCE_TYPECODE(RTI_INT32_MAX,NULL);
                static DDS_TypeCode GPSStatus__g_tc_satellite_visible_azimuth__sequence = DDS_INITIALIZE_SEQUENCE_TYPECODE(RTI_INT32_MAX,NULL);
                static DDS_TypeCode GPSStatus__g_tc_satellite_visible_snr__sequence = DDS_INITIALIZE_SEQUENCE_TYPECODE(RTI_INT32_MAX,NULL);
                static DDS_TypeCode_Member GPSStatus__g_tc_members[12]=
                {

                    {
                        (char *)"header_",/* Member name */
                        {
                            0,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellites_used_",/* Member name */
                        {
                            1,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellite_used_prn_",/* Member name */
                        {
                            2,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellites_visible_",/* Member name */
                        {
                            3,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellite_visible_prn_",/* Member name */
                        {
                            4,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellite_visible_z_",/* Member name */
                        {
                            5,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellite_visible_azimuth_",/* Member name */
                        {
                            6,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"satellite_visible_snr_",/* Member name */
                        {
                            7,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"status_",/* Member name */
                        {
                            8,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"motion_source_",/* Member name */
                        {
                            9,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"orientation_source_",/* Member name */
                        {
                            10,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"position_source_",/* Member name */
                        {
                            11,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }
                };

                static DDS_TypeCode GPSStatus__g_tc =
                {{
                        DDS_TK_STRUCT,/* Kind */
                        DDS_BOOLEAN_FALSE, /* Ignored */
                        -1, /*Ignored*/
                        (char *)"gps_msgs::msg::dds_::GPSStatus_", /* Name */
                        NULL, /* Ignored */      
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        12, /* Number of members */
                        GPSStatus__g_tc_members, /* Members */
                        DDS_VM_NONE  /* Ignored */         
                    }}; /* Type code for GPSStatus_*/

                if (is_initialized) {
                    return &GPSStatus__g_tc;
                }

                GPSStatus__g_tc_satellite_used_prn__sequence._data._typeCode = (RTICdrTypeCode *)&DDS_g_tc_long;

                GPSStatus__g_tc_satellite_visible_prn__sequence._data._typeCode = (RTICdrTypeCode *)&DDS_g_tc_long;

                GPSStatus__g_tc_satellite_visible_z__sequence._data._typeCode = (RTICdrTypeCode *)&DDS_g_tc_long;

                GPSStatus__g_tc_satellite_visible_azimuth__sequence._data._typeCode = (RTICdrTypeCode *)&DDS_g_tc_long;

                GPSStatus__g_tc_satellite_visible_snr__sequence._data._typeCode = (RTICdrTypeCode *)&DDS_g_tc_long;

                GPSStatus__g_tc_members[0]._representation._typeCode = (RTICdrTypeCode *)std_msgs::msg::dds_::Header__get_typecode();

                GPSStatus__g_tc_members[1]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ushort;

                GPSStatus__g_tc_members[2]._representation._typeCode = (RTICdrTypeCode *)& GPSStatus__g_tc_satellite_used_prn__sequence;
                GPSStatus__g_tc_members[3]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ushort;

                GPSStatus__g_tc_members[4]._representation._typeCode = (RTICdrTypeCode *)& GPSStatus__g_tc_satellite_visible_prn__sequence;
                GPSStatus__g_tc_members[5]._representation._typeCode = (RTICdrTypeCode *)& GPSStatus__g_tc_satellite_visible_z__sequence;
                GPSStatus__g_tc_members[6]._representation._typeCode = (RTICdrTypeCode *)& GPSStatus__g_tc_satellite_visible_azimuth__sequence;
                GPSStatus__g_tc_members[7]._representation._typeCode = (RTICdrTypeCode *)& GPSStatus__g_tc_satellite_visible_snr__sequence;
                GPSStatus__g_tc_members[8]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_short;

                GPSStatus__g_tc_members[9]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ushort;

                GPSStatus__g_tc_members[10]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ushort;

                GPSStatus__g_tc_members[11]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ushort;

                is_initialized = RTI_TRUE;

                return &GPSStatus__g_tc;
            }

            RTIBool GPSStatus__initialize(
                GPSStatus_* sample) {
                return gps_msgs::msg::dds_::GPSStatus__initialize_ex(sample,RTI_TRUE,RTI_TRUE);
            }

            RTIBool GPSStatus__initialize_ex(
                GPSStatus_* sample,RTIBool allocatePointers, RTIBool allocateMemory)
            {

                struct DDS_TypeAllocationParams_t allocParams =
                DDS_TYPE_ALLOCATION_PARAMS_DEFAULT;

                allocParams.allocate_pointers =  (DDS_Boolean)allocatePointers;
                allocParams.allocate_memory = (DDS_Boolean)allocateMemory;

                return gps_msgs::msg::dds_::GPSStatus__initialize_w_params(
                    sample,&allocParams);

            }

            RTIBool GPSStatus__initialize_w_params(
                GPSStatus_* sample, const struct DDS_TypeAllocationParams_t * allocParams)
            {

                void* buffer = NULL;
                if (buffer) {} /* To avoid warnings */

                if (sample == NULL) {
                    return RTI_FALSE;
                }
                if (allocParams == NULL) {
                    return RTI_FALSE;
                }

                if (!std_msgs::msg::dds_::Header__initialize_w_params(&sample->header_,
                allocParams)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initUnsignedShort(&sample->satellites_used_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory) {
                    DDS_LongSeq_initialize(&sample->satellite_used_prn_  );
                    DDS_LongSeq_set_absolute_maximum(&sample->satellite_used_prn_ , RTI_INT32_MAX);
                    if (!DDS_LongSeq_set_maximum(&sample->satellite_used_prn_ , (0))) {
                        return RTI_FALSE;
                    }
                } else { 
                    DDS_LongSeq_set_length(&sample->satellite_used_prn_, 0);
                }

                if (!RTICdrType_initUnsignedShort(&sample->satellites_visible_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory) {
                    DDS_LongSeq_initialize(&sample->satellite_visible_prn_  );
                    DDS_LongSeq_set_absolute_maximum(&sample->satellite_visible_prn_ , RTI_INT32_MAX);
                    if (!DDS_LongSeq_set_maximum(&sample->satellite_visible_prn_ , (0))) {
                        return RTI_FALSE;
                    }
                } else { 
                    DDS_LongSeq_set_length(&sample->satellite_visible_prn_, 0);
                }
                if (allocParams->allocate_memory) {
                    DDS_LongSeq_initialize(&sample->satellite_visible_z_  );
                    DDS_LongSeq_set_absolute_maximum(&sample->satellite_visible_z_ , RTI_INT32_MAX);
                    if (!DDS_LongSeq_set_maximum(&sample->satellite_visible_z_ , (0))) {
                        return RTI_FALSE;
                    }
                } else { 
                    DDS_LongSeq_set_length(&sample->satellite_visible_z_, 0);
                }
                if (allocParams->allocate_memory) {
                    DDS_LongSeq_initialize(&sample->satellite_visible_azimuth_  );
                    DDS_LongSeq_set_absolute_maximum(&sample->satellite_visible_azimuth_ , RTI_INT32_MAX);
                    if (!DDS_LongSeq_set_maximum(&sample->satellite_visible_azimuth_ , (0))) {
                        return RTI_FALSE;
                    }
                } else { 
                    DDS_LongSeq_set_length(&sample->satellite_visible_azimuth_, 0);
                }
                if (allocParams->allocate_memory) {
                    DDS_LongSeq_initialize(&sample->satellite_visible_snr_  );
                    DDS_LongSeq_set_absolute_maximum(&sample->satellite_visible_snr_ , RTI_INT32_MAX);
                    if (!DDS_LongSeq_set_maximum(&sample->satellite_visible_snr_ , (0))) {
                        return RTI_FALSE;
                    }
                } else { 
                    DDS_LongSeq_set_length(&sample->satellite_visible_snr_, 0);
                }

                if (!RTICdrType_initShort(&sample->status_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initUnsignedShort(&sample->motion_source_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initUnsignedShort(&sample->orientation_source_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initUnsignedShort(&sample->position_source_)) {
                    return RTI_FALSE;
                }

                return RTI_TRUE;
            }

            void GPSStatus__finalize(
                GPSStatus_* sample)
            {

                gps_msgs::msg::dds_::GPSStatus__finalize_ex(sample,RTI_TRUE);
            }

            void GPSStatus__finalize_ex(
                GPSStatus_* sample,RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParams =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;

                if (sample==NULL) {
                    return;
                } 

                deallocParams.delete_pointers = (DDS_Boolean)deletePointers;

                gps_msgs::msg::dds_::GPSStatus__finalize_w_params(
                    sample,&deallocParams);
            }

            void GPSStatus__finalize_w_params(
                GPSStatus_* sample,const struct DDS_TypeDeallocationParams_t * deallocParams)
            {

                if (sample==NULL) {
                    return;
                }

                if (deallocParams == NULL) {
                    return;
                }

                std_msgs::msg::dds_::Header__finalize_w_params(&sample->header_,deallocParams);

                DDS_LongSeq_finalize(&sample->satellite_used_prn_);

                DDS_LongSeq_finalize(&sample->satellite_visible_prn_);

                DDS_LongSeq_finalize(&sample->satellite_visible_z_);

                DDS_LongSeq_finalize(&sample->satellite_visible_azimuth_);

                DDS_LongSeq_finalize(&sample->satellite_visible_snr_);

            }

            void GPSStatus__finalize_optional_members(
                GPSStatus_* sample, RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParamsTmp =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;
                struct DDS_TypeDeallocationParams_t * deallocParams =
                &deallocParamsTmp;

                if (sample==NULL) {
                    return;
                } 
                if (deallocParams) {} /* To avoid warnings */

                deallocParamsTmp.delete_pointers = (DDS_Boolean)deletePointers;
                deallocParamsTmp.delete_optional_members = DDS_BOOLEAN_TRUE;

                std_msgs::msg::dds_::Header__finalize_optional_members(&sample->header_, deallocParams->delete_pointers);
            }

            RTIBool GPSStatus__copy(
                GPSStatus_* dst,
                const GPSStatus_* src)
            {
                try {

                    if (dst == NULL || src == NULL) {
                        return RTI_FALSE;
                    }

                    if (!std_msgs::msg::dds_::Header__copy(
                        &dst->header_,(const std_msgs::msg::dds_::Header_*)&src->header_)) {
                        return RTI_FALSE;
                    } 
                    if (!RTICdrType_copyUnsignedShort (
                        &dst->satellites_used_, &src->satellites_used_)) { 
                        return RTI_FALSE;
                    }
                    if (!DDS_LongSeq_copy(&dst->satellite_used_prn_ ,
                    &src->satellite_used_prn_ )) {
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedShort (
                        &dst->satellites_visible_, &src->satellites_visible_)) { 
                        return RTI_FALSE;
                    }
                    if (!DDS_LongSeq_copy(&dst->satellite_visible_prn_ ,
                    &src->satellite_visible_prn_ )) {
                        return RTI_FALSE;
                    }
                    if (!DDS_LongSeq_copy(&dst->satellite_visible_z_ ,
                    &src->satellite_visible_z_ )) {
                        return RTI_FALSE;
                    }
                    if (!DDS_LongSeq_copy(&dst->satellite_visible_azimuth_ ,
                    &src->satellite_visible_azimuth_ )) {
                        return RTI_FALSE;
                    }
                    if (!DDS_LongSeq_copy(&dst->satellite_visible_snr_ ,
                    &src->satellite_visible_snr_ )) {
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyShort (
                        &dst->status_, &src->status_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedShort (
                        &dst->motion_source_, &src->motion_source_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedShort (
                        &dst->orientation_source_, &src->orientation_source_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedShort (
                        &dst->position_source_, &src->position_source_)) { 
                        return RTI_FALSE;
                    }

                    return RTI_TRUE;

                } catch (std::bad_alloc&) {
                    return RTI_FALSE;
                }
            }

            /**
            * <<IMPLEMENTATION>>
            *
            * Defines:  TSeq, T
            *
            * Configure and implement 'GPSStatus_' sequence class.
            */
            #define T GPSStatus_
            #define TSeq GPSStatus_Seq

            #define T_initialize_w_params gps_msgs::msg::dds_::GPSStatus__initialize_w_params

            #define T_finalize_w_params   gps_msgs::msg::dds_::GPSStatus__finalize_w_params
            #define T_copy       gps_msgs::msg::dds_::GPSStatus__copy

            #ifndef NDDS_STANDALONE_TYPE
            #include "dds_c/generic/dds_c_sequence_TSeq.gen"
            #include "dds_cpp/generic/dds_cpp_sequence_TSeq.gen"
            #else
            #include "dds_c_sequence_TSeq.gen"
            #include "dds_cpp_sequence_TSeq.gen"
            #endif

            #undef T_copy
            #undef T_finalize_w_params

            #undef T_initialize_w_params

            #undef TSeq
            #undef T
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace gps_msgs  */

