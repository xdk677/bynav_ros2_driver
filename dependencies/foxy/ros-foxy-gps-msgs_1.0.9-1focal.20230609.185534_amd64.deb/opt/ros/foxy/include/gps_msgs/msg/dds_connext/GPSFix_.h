

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from GPSFix_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef GPSFix__1599587495_h
#define GPSFix__1599587495_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "gps_msgs/msg/dds_connext/GPSStatus_.h"
#include "std_msgs/msg/dds_connext/Header_.h"
namespace gps_msgs {
    namespace msg {
        namespace dds_ {
            namespace GPSFix_Constants {
                static const DDS_Octet COVARIANCE_TYPE_UNKNOWN_= 0;
                static const DDS_Octet COVARIANCE_TYPE_APPROXIMATED_= 1;
                static const DDS_Octet COVARIANCE_TYPE_DIAGONAL_KNOWN_= 2;
                static const DDS_Octet COVARIANCE_TYPE_KNOWN_= 3;
            } /* namespace GPSFix_Constants  */

            extern const char *GPSFix_TYPENAME;

            struct GPSFix_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class GPSFix_TypeSupport;
            class GPSFix_DataWriter;
            class GPSFix_DataReader;
            #endif

            class GPSFix_ 
            {
              public:
                typedef struct GPSFix_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef GPSFix_TypeSupport TypeSupport;
                typedef GPSFix_DataWriter DataWriter;
                typedef GPSFix_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                gps_msgs::msg::dds_::GPSStatus_   status_ ;
                DDS_Double   latitude_ ;
                DDS_Double   longitude_ ;
                DDS_Double   altitude_ ;
                DDS_Double   track_ ;
                DDS_Double   speed_ ;
                DDS_Double   climb_ ;
                DDS_Double   pitch_ ;
                DDS_Double   roll_ ;
                DDS_Double   dip_ ;
                DDS_Double   time_ ;
                DDS_Double   gdop_ ;
                DDS_Double   pdop_ ;
                DDS_Double   hdop_ ;
                DDS_Double   vdop_ ;
                DDS_Double   tdop_ ;
                DDS_Double   err_ ;
                DDS_Double   err_horz_ ;
                DDS_Double   err_vert_ ;
                DDS_Double   err_track_ ;
                DDS_Double   err_speed_ ;
                DDS_Double   err_climb_ ;
                DDS_Double   err_time_ ;
                DDS_Double   err_pitch_ ;
                DDS_Double   err_roll_ ;
                DDS_Double   err_dip_ ;
                DDS_Double   position_covariance_ [9];
                DDS_Octet   position_covariance_type_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* GPSFix__get_typecode(void); /* Type code */

            DDS_SEQUENCE(GPSFix_Seq, GPSFix_);

            NDDSUSERDllExport
            RTIBool GPSFix__initialize(
                GPSFix_* self);

            NDDSUSERDllExport
            RTIBool GPSFix__initialize_ex(
                GPSFix_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool GPSFix__initialize_w_params(
                GPSFix_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void GPSFix__finalize(
                GPSFix_* self);

            NDDSUSERDllExport
            void GPSFix__finalize_ex(
                GPSFix_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void GPSFix__finalize_w_params(
                GPSFix_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void GPSFix__finalize_optional_members(
                GPSFix_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool GPSFix__copy(
                GPSFix_* dst,
                const GPSFix_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace gps_msgs  */

#endif /* GPSFix_ */

