

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from GPSStatus_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef GPSStatus__633814198_h
#define GPSStatus__633814198_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "std_msgs/msg/dds_connext/Header_.h"
namespace gps_msgs {
    namespace msg {
        namespace dds_ {
            namespace GPSStatus_Constants {
                static const DDS_Short STATUS_NO_FIX_= -1;
                static const DDS_Short STATUS_FIX_= 0;
                static const DDS_Short STATUS_SBAS_FIX_= 1;
                static const DDS_Short STATUS_GBAS_FIX_= 2;
                static const DDS_Short STATUS_DGPS_FIX_= 18;
                static const DDS_Short STATUS_WAAS_FIX_= 33;
                static const DDS_UnsignedShort SOURCE_NONE_= 0;
                static const DDS_UnsignedShort SOURCE_GPS_= 1;
                static const DDS_UnsignedShort SOURCE_POINTS_= 2;
                static const DDS_UnsignedShort SOURCE_DOPPLER_= 4;
                static const DDS_UnsignedShort SOURCE_ALTIMETER_= 8;
                static const DDS_UnsignedShort SOURCE_MAGNETIC_= 16;
                static const DDS_UnsignedShort SOURCE_GYRO_= 32;
                static const DDS_UnsignedShort SOURCE_ACCEL_= 64;
            } /* namespace GPSStatus_Constants  */

            extern const char *GPSStatus_TYPENAME;

            struct GPSStatus_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class GPSStatus_TypeSupport;
            class GPSStatus_DataWriter;
            class GPSStatus_DataReader;
            #endif

            class GPSStatus_ 
            {
              public:
                typedef struct GPSStatus_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef GPSStatus_TypeSupport TypeSupport;
                typedef GPSStatus_DataWriter DataWriter;
                typedef GPSStatus_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_UnsignedShort   satellites_used_ ;
                DDS_LongSeq  satellite_used_prn_ ;
                DDS_UnsignedShort   satellites_visible_ ;
                DDS_LongSeq  satellite_visible_prn_ ;
                DDS_LongSeq  satellite_visible_z_ ;
                DDS_LongSeq  satellite_visible_azimuth_ ;
                DDS_LongSeq  satellite_visible_snr_ ;
                DDS_Short   status_ ;
                DDS_UnsignedShort   motion_source_ ;
                DDS_UnsignedShort   orientation_source_ ;
                DDS_UnsignedShort   position_source_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* GPSStatus__get_typecode(void); /* Type code */

            DDS_SEQUENCE(GPSStatus_Seq, GPSStatus_);

            NDDSUSERDllExport
            RTIBool GPSStatus__initialize(
                GPSStatus_* self);

            NDDSUSERDllExport
            RTIBool GPSStatus__initialize_ex(
                GPSStatus_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool GPSStatus__initialize_w_params(
                GPSStatus_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void GPSStatus__finalize(
                GPSStatus_* self);

            NDDSUSERDllExport
            void GPSStatus__finalize_ex(
                GPSStatus_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void GPSStatus__finalize_w_params(
                GPSStatus_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void GPSStatus__finalize_optional_members(
                GPSStatus_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool GPSStatus__copy(
                GPSStatus_* dst,
                const GPSStatus_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace gps_msgs  */

#endif /* GPSStatus_ */

