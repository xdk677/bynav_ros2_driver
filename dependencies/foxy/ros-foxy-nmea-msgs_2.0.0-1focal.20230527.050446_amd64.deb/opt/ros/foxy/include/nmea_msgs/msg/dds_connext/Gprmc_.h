

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gprmc_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Gprmc__350037768_h
#define Gprmc__350037768_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "std_msgs/msg/dds_connext/Header_.h"
namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *Gprmc_TYPENAME;

            struct Gprmc_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Gprmc_TypeSupport;
            class Gprmc_DataWriter;
            class Gprmc_DataReader;
            #endif

            class Gprmc_ 
            {
              public:
                typedef struct Gprmc_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Gprmc_TypeSupport TypeSupport;
                typedef Gprmc_DataWriter DataWriter;
                typedef Gprmc_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_Char *   message_id_ ;
                DDS_Double   utc_seconds_ ;
                DDS_Char *   position_status_ ;
                DDS_Double   lat_ ;
                DDS_Double   lon_ ;
                DDS_Char *   lat_dir_ ;
                DDS_Char *   lon_dir_ ;
                DDS_Float   speed_ ;
                DDS_Float   track_ ;
                DDS_Char *   date_ ;
                DDS_Float   mag_var_ ;
                DDS_Char *   mag_var_direction_ ;
                DDS_Char *   mode_indicator_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Gprmc__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Gprmc_Seq, Gprmc_);

            NDDSUSERDllExport
            RTIBool Gprmc__initialize(
                Gprmc_* self);

            NDDSUSERDllExport
            RTIBool Gprmc__initialize_ex(
                Gprmc_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Gprmc__initialize_w_params(
                Gprmc_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Gprmc__finalize(
                Gprmc_* self);

            NDDSUSERDllExport
            void Gprmc__finalize_ex(
                Gprmc_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Gprmc__finalize_w_params(
                Gprmc_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Gprmc__finalize_optional_members(
                Gprmc_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Gprmc__copy(
                Gprmc_* dst,
                const Gprmc_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* Gprmc_ */

