

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gprmc_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#ifndef dds_c_log_impl_h              
#include "dds_c/dds_c_log_impl.h"                                
#endif        

#ifndef cdr_type_h
#include "cdr/cdr_type.h"
#endif    

#ifndef osapi_heap_h
#include "osapi/osapi_heap.h" 
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "Gprmc_.h"

#include <new>

namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            /* ========================================================================= */
            const char *Gprmc_TYPENAME = "nmea_msgs::msg::dds_::Gprmc_";

            DDS_TypeCode* Gprmc__get_typecode()
            {
                static RTIBool is_initialized = RTI_FALSE;

                static DDS_TypeCode Gprmc__g_tc_message_id__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_position_status__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_lat_dir__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_lon_dir__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_date__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_mag_var_direction__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gprmc__g_tc_mode_indicator__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode_Member Gprmc__g_tc_members[14]=
                {

                    {
                        (char *)"header_",/* Member name */
                        {
                            0,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"message_id_",/* Member name */
                        {
                            1,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"utc_seconds_",/* Member name */
                        {
                            2,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"position_status_",/* Member name */
                        {
                            3,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lat_",/* Member name */
                        {
                            4,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lon_",/* Member name */
                        {
                            5,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lat_dir_",/* Member name */
                        {
                            6,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lon_dir_",/* Member name */
                        {
                            7,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"speed_",/* Member name */
                        {
                            8,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"track_",/* Member name */
                        {
                            9,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"date_",/* Member name */
                        {
                            10,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"mag_var_",/* Member name */
                        {
                            11,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"mag_var_direction_",/* Member name */
                        {
                            12,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"mode_indicator_",/* Member name */
                        {
                            13,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }
                };

                static DDS_TypeCode Gprmc__g_tc =
                {{
                        DDS_TK_STRUCT,/* Kind */
                        DDS_BOOLEAN_FALSE, /* Ignored */
                        -1, /*Ignored*/
                        (char *)"nmea_msgs::msg::dds_::Gprmc_", /* Name */
                        NULL, /* Ignored */      
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        14, /* Number of members */
                        Gprmc__g_tc_members, /* Members */
                        DDS_VM_NONE  /* Ignored */         
                    }}; /* Type code for Gprmc_*/

                if (is_initialized) {
                    return &Gprmc__g_tc;
                }

                Gprmc__g_tc_members[0]._representation._typeCode = (RTICdrTypeCode *)std_msgs::msg::dds_::Header__get_typecode();

                Gprmc__g_tc_members[1]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_message_id__string;

                Gprmc__g_tc_members[2]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gprmc__g_tc_members[3]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_position_status__string;

                Gprmc__g_tc_members[4]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gprmc__g_tc_members[5]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gprmc__g_tc_members[6]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_lat_dir__string;

                Gprmc__g_tc_members[7]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_lon_dir__string;

                Gprmc__g_tc_members[8]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gprmc__g_tc_members[9]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gprmc__g_tc_members[10]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_date__string;

                Gprmc__g_tc_members[11]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gprmc__g_tc_members[12]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_mag_var_direction__string;

                Gprmc__g_tc_members[13]._representation._typeCode = (RTICdrTypeCode *)&Gprmc__g_tc_mode_indicator__string;

                is_initialized = RTI_TRUE;

                return &Gprmc__g_tc;
            }

            RTIBool Gprmc__initialize(
                Gprmc_* sample) {
                return nmea_msgs::msg::dds_::Gprmc__initialize_ex(sample,RTI_TRUE,RTI_TRUE);
            }

            RTIBool Gprmc__initialize_ex(
                Gprmc_* sample,RTIBool allocatePointers, RTIBool allocateMemory)
            {

                struct DDS_TypeAllocationParams_t allocParams =
                DDS_TYPE_ALLOCATION_PARAMS_DEFAULT;

                allocParams.allocate_pointers =  (DDS_Boolean)allocatePointers;
                allocParams.allocate_memory = (DDS_Boolean)allocateMemory;

                return nmea_msgs::msg::dds_::Gprmc__initialize_w_params(
                    sample,&allocParams);

            }

            RTIBool Gprmc__initialize_w_params(
                Gprmc_* sample, const struct DDS_TypeAllocationParams_t * allocParams)
            {

                if (sample == NULL) {
                    return RTI_FALSE;
                }
                if (allocParams == NULL) {
                    return RTI_FALSE;
                }

                if (!std_msgs::msg::dds_::Header__initialize_w_params(&sample->header_,
                allocParams)) {
                    return RTI_FALSE;
                }
                if (allocParams->allocate_memory){
                    sample->message_id_= DDS_String_alloc ((0));
                    if (sample->message_id_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->message_id_!= NULL) { 
                        sample->message_id_[0] = '\0';
                    }
                }

                if (!RTICdrType_initDouble(&sample->utc_seconds_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->position_status_= DDS_String_alloc ((0));
                    if (sample->position_status_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->position_status_!= NULL) { 
                        sample->position_status_[0] = '\0';
                    }
                }

                if (!RTICdrType_initDouble(&sample->lat_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initDouble(&sample->lon_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->lat_dir_= DDS_String_alloc ((0));
                    if (sample->lat_dir_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->lat_dir_!= NULL) { 
                        sample->lat_dir_[0] = '\0';
                    }
                }

                if (allocParams->allocate_memory){
                    sample->lon_dir_= DDS_String_alloc ((0));
                    if (sample->lon_dir_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->lon_dir_!= NULL) { 
                        sample->lon_dir_[0] = '\0';
                    }
                }

                if (!RTICdrType_initFloat(&sample->speed_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initFloat(&sample->track_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->date_= DDS_String_alloc ((0));
                    if (sample->date_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->date_!= NULL) { 
                        sample->date_[0] = '\0';
                    }
                }

                if (!RTICdrType_initFloat(&sample->mag_var_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->mag_var_direction_= DDS_String_alloc ((0));
                    if (sample->mag_var_direction_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->mag_var_direction_!= NULL) { 
                        sample->mag_var_direction_[0] = '\0';
                    }
                }

                if (allocParams->allocate_memory){
                    sample->mode_indicator_= DDS_String_alloc ((0));
                    if (sample->mode_indicator_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->mode_indicator_!= NULL) { 
                        sample->mode_indicator_[0] = '\0';
                    }
                }

                return RTI_TRUE;
            }

            void Gprmc__finalize(
                Gprmc_* sample)
            {

                nmea_msgs::msg::dds_::Gprmc__finalize_ex(sample,RTI_TRUE);
            }

            void Gprmc__finalize_ex(
                Gprmc_* sample,RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParams =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;

                if (sample==NULL) {
                    return;
                } 

                deallocParams.delete_pointers = (DDS_Boolean)deletePointers;

                nmea_msgs::msg::dds_::Gprmc__finalize_w_params(
                    sample,&deallocParams);
            }

            void Gprmc__finalize_w_params(
                Gprmc_* sample,const struct DDS_TypeDeallocationParams_t * deallocParams)
            {

                if (sample==NULL) {
                    return;
                }

                if (deallocParams == NULL) {
                    return;
                }

                std_msgs::msg::dds_::Header__finalize_w_params(&sample->header_,deallocParams);

                if (sample->message_id_ != NULL) {
                    DDS_String_free(sample->message_id_);
                    sample->message_id_=NULL;

                }

                if (sample->position_status_ != NULL) {
                    DDS_String_free(sample->position_status_);
                    sample->position_status_=NULL;

                }

                if (sample->lat_dir_ != NULL) {
                    DDS_String_free(sample->lat_dir_);
                    sample->lat_dir_=NULL;

                }
                if (sample->lon_dir_ != NULL) {
                    DDS_String_free(sample->lon_dir_);
                    sample->lon_dir_=NULL;

                }

                if (sample->date_ != NULL) {
                    DDS_String_free(sample->date_);
                    sample->date_=NULL;

                }

                if (sample->mag_var_direction_ != NULL) {
                    DDS_String_free(sample->mag_var_direction_);
                    sample->mag_var_direction_=NULL;

                }
                if (sample->mode_indicator_ != NULL) {
                    DDS_String_free(sample->mode_indicator_);
                    sample->mode_indicator_=NULL;

                }
            }

            void Gprmc__finalize_optional_members(
                Gprmc_* sample, RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParamsTmp =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;
                struct DDS_TypeDeallocationParams_t * deallocParams =
                &deallocParamsTmp;

                if (sample==NULL) {
                    return;
                } 
                if (deallocParams) {} /* To avoid warnings */

                deallocParamsTmp.delete_pointers = (DDS_Boolean)deletePointers;
                deallocParamsTmp.delete_optional_members = DDS_BOOLEAN_TRUE;

                std_msgs::msg::dds_::Header__finalize_optional_members(&sample->header_, deallocParams->delete_pointers);
            }

            RTIBool Gprmc__copy(
                Gprmc_* dst,
                const Gprmc_* src)
            {
                try {

                    if (dst == NULL || src == NULL) {
                        return RTI_FALSE;
                    }

                    if (!std_msgs::msg::dds_::Header__copy(
                        &dst->header_,(const std_msgs::msg::dds_::Header_*)&src->header_)) {
                        return RTI_FALSE;
                    } 
                    if (!RTICdrType_copyStringEx (
                        &dst->message_id_, src->message_id_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->utc_seconds_, &src->utc_seconds_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->position_status_, src->position_status_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->lat_, &src->lat_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->lon_, &src->lon_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->lat_dir_, src->lat_dir_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->lon_dir_, src->lon_dir_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->speed_, &src->speed_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->track_, &src->track_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->date_, src->date_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->mag_var_, &src->mag_var_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->mag_var_direction_, src->mag_var_direction_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->mode_indicator_, src->mode_indicator_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }

                    return RTI_TRUE;

                } catch (std::bad_alloc&) {
                    return RTI_FALSE;
                }
            }

            /**
            * <<IMPLEMENTATION>>
            *
            * Defines:  TSeq, T
            *
            * Configure and implement 'Gprmc_' sequence class.
            */
            #define T Gprmc_
            #define TSeq Gprmc_Seq

            #define T_initialize_w_params nmea_msgs::msg::dds_::Gprmc__initialize_w_params

            #define T_finalize_w_params   nmea_msgs::msg::dds_::Gprmc__finalize_w_params
            #define T_copy       nmea_msgs::msg::dds_::Gprmc__copy

            #ifndef NDDS_STANDALONE_TYPE
            #include "dds_c/generic/dds_c_sequence_TSeq.gen"
            #include "dds_cpp/generic/dds_cpp_sequence_TSeq.gen"
            #else
            #include "dds_c_sequence_TSeq.gen"
            #include "dds_cpp_sequence_TSeq.gen"
            #endif

            #undef T_copy
            #undef T_finalize_w_params

            #undef T_initialize_w_params

            #undef TSeq
            #undef T
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

