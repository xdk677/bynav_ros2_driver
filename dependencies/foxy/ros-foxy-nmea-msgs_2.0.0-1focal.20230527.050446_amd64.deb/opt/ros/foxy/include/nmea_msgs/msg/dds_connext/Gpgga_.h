

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gpgga_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Gpgga__1566647526_h
#define Gpgga__1566647526_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "std_msgs/msg/dds_connext/Header_.h"
namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *Gpgga_TYPENAME;

            struct Gpgga_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Gpgga_TypeSupport;
            class Gpgga_DataWriter;
            class Gpgga_DataReader;
            #endif

            class Gpgga_ 
            {
              public:
                typedef struct Gpgga_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Gpgga_TypeSupport TypeSupport;
                typedef Gpgga_DataWriter DataWriter;
                typedef Gpgga_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_Char *   message_id_ ;
                DDS_Double   utc_seconds_ ;
                DDS_Double   lat_ ;
                DDS_Double   lon_ ;
                DDS_Char *   lat_dir_ ;
                DDS_Char *   lon_dir_ ;
                DDS_UnsignedLong   gps_qual_ ;
                DDS_UnsignedLong   num_sats_ ;
                DDS_Float   hdop_ ;
                DDS_Float   alt_ ;
                DDS_Char *   altitude_units_ ;
                DDS_Float   undulation_ ;
                DDS_Char *   undulation_units_ ;
                DDS_UnsignedLong   diff_age_ ;
                DDS_Char *   station_id_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Gpgga__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Gpgga_Seq, Gpgga_);

            NDDSUSERDllExport
            RTIBool Gpgga__initialize(
                Gpgga_* self);

            NDDSUSERDllExport
            RTIBool Gpgga__initialize_ex(
                Gpgga_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Gpgga__initialize_w_params(
                Gpgga_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Gpgga__finalize(
                Gpgga_* self);

            NDDSUSERDllExport
            void Gpgga__finalize_ex(
                Gpgga_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Gpgga__finalize_w_params(
                Gpgga_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Gpgga__finalize_optional_members(
                Gpgga_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Gpgga__copy(
                Gpgga_* dst,
                const Gpgga_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* Gpgga_ */

