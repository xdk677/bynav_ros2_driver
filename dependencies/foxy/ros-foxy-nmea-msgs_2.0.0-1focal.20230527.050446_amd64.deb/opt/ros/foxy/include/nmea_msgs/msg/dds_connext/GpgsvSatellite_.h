

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from GpgsvSatellite_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef GpgsvSatellite__191838223_h
#define GpgsvSatellite__191838223_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *GpgsvSatellite_TYPENAME;

            struct GpgsvSatellite_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class GpgsvSatellite_TypeSupport;
            class GpgsvSatellite_DataWriter;
            class GpgsvSatellite_DataReader;
            #endif

            class GpgsvSatellite_ 
            {
              public:
                typedef struct GpgsvSatellite_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef GpgsvSatellite_TypeSupport TypeSupport;
                typedef GpgsvSatellite_DataWriter DataWriter;
                typedef GpgsvSatellite_DataReader DataReader;
                #endif

                DDS_Octet   prn_ ;
                DDS_Octet   elevation_ ;
                DDS_UnsignedShort   azimuth_ ;
                DDS_Octet   snr_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* GpgsvSatellite__get_typecode(void); /* Type code */

            DDS_SEQUENCE(GpgsvSatellite_Seq, GpgsvSatellite_);

            NDDSUSERDllExport
            RTIBool GpgsvSatellite__initialize(
                GpgsvSatellite_* self);

            NDDSUSERDllExport
            RTIBool GpgsvSatellite__initialize_ex(
                GpgsvSatellite_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool GpgsvSatellite__initialize_w_params(
                GpgsvSatellite_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void GpgsvSatellite__finalize(
                GpgsvSatellite_* self);

            NDDSUSERDllExport
            void GpgsvSatellite__finalize_ex(
                GpgsvSatellite_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void GpgsvSatellite__finalize_w_params(
                GpgsvSatellite_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void GpgsvSatellite__finalize_optional_members(
                GpgsvSatellite_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool GpgsvSatellite__copy(
                GpgsvSatellite_* dst,
                const GpgsvSatellite_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* GpgsvSatellite_ */

