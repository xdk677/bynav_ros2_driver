// generated from rosidl_generator_c/resource/idl.h.em
// with input from nmea_msgs:msg/Gpgsv.idl
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPGSV_H_
#define NMEA_MSGS__MSG__GPGSV_H_

#include "nmea_msgs/msg/detail/gpgsv__struct.h"
#include "nmea_msgs/msg/detail/gpgsv__functions.h"
#include "nmea_msgs/msg/detail/gpgsv__type_support.h"

#endif  // NMEA_MSGS__MSG__GPGSV_H_
