// generated from rosidl_generator_c/resource/idl.h.em
// with input from nmea_msgs:msg/Gprmc.idl
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPRMC_H_
#define NMEA_MSGS__MSG__GPRMC_H_

#include "nmea_msgs/msg/detail/gprmc__struct.h"
#include "nmea_msgs/msg/detail/gprmc__functions.h"
#include "nmea_msgs/msg/detail/gprmc__type_support.h"

#endif  // NMEA_MSGS__MSG__GPRMC_H_
