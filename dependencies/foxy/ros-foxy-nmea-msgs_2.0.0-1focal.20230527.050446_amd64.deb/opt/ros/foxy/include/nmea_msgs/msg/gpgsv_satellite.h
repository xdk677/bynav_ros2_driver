// generated from rosidl_generator_c/resource/idl.h.em
// with input from nmea_msgs:msg/GpgsvSatellite.idl
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPGSV_SATELLITE_H_
#define NMEA_MSGS__MSG__GPGSV_SATELLITE_H_

#include "nmea_msgs/msg/detail/gpgsv_satellite__struct.h"
#include "nmea_msgs/msg/detail/gpgsv_satellite__functions.h"
#include "nmea_msgs/msg/detail/gpgsv_satellite__type_support.h"

#endif  // NMEA_MSGS__MSG__GPGSV_SATELLITE_H_
