

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gpgsv_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Gpgsv__66999515_h
#define Gpgsv__66999515_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "nmea_msgs/msg/dds_connext/GpgsvSatellite_.h"
#include "std_msgs/msg/dds_connext/Header_.h"
namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *Gpgsv_TYPENAME;

            struct Gpgsv_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Gpgsv_TypeSupport;
            class Gpgsv_DataWriter;
            class Gpgsv_DataReader;
            #endif

            class Gpgsv_ 
            {
              public:
                typedef struct Gpgsv_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Gpgsv_TypeSupport TypeSupport;
                typedef Gpgsv_DataWriter DataWriter;
                typedef Gpgsv_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_Char *   message_id_ ;
                DDS_Octet   n_msgs_ ;
                DDS_Octet   msg_number_ ;
                DDS_Octet   n_satellites_ ;
                nmea_msgs::msg::dds_::GpgsvSatellite_Seq  satellites_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Gpgsv__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Gpgsv_Seq, Gpgsv_);

            NDDSUSERDllExport
            RTIBool Gpgsv__initialize(
                Gpgsv_* self);

            NDDSUSERDllExport
            RTIBool Gpgsv__initialize_ex(
                Gpgsv_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Gpgsv__initialize_w_params(
                Gpgsv_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Gpgsv__finalize(
                Gpgsv_* self);

            NDDSUSERDllExport
            void Gpgsv__finalize_ex(
                Gpgsv_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Gpgsv__finalize_w_params(
                Gpgsv_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Gpgsv__finalize_optional_members(
                Gpgsv_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Gpgsv__copy(
                Gpgsv_* dst,
                const Gpgsv_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* Gpgsv_ */

