

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gpgsa_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Gpgsa__668211620_h
#define Gpgsa__668211620_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "std_msgs/msg/dds_connext/Header_.h"
namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *Gpgsa_TYPENAME;

            struct Gpgsa_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Gpgsa_TypeSupport;
            class Gpgsa_DataWriter;
            class Gpgsa_DataReader;
            #endif

            class Gpgsa_ 
            {
              public:
                typedef struct Gpgsa_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Gpgsa_TypeSupport TypeSupport;
                typedef Gpgsa_DataWriter DataWriter;
                typedef Gpgsa_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_Char *   message_id_ ;
                DDS_Char *   auto_manual_mode_ ;
                DDS_Octet   fix_mode_ ;
                DDS_OctetSeq  sv_ids_ ;
                DDS_Float   pdop_ ;
                DDS_Float   hdop_ ;
                DDS_Float   vdop_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Gpgsa__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Gpgsa_Seq, Gpgsa_);

            NDDSUSERDllExport
            RTIBool Gpgsa__initialize(
                Gpgsa_* self);

            NDDSUSERDllExport
            RTIBool Gpgsa__initialize_ex(
                Gpgsa_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Gpgsa__initialize_w_params(
                Gpgsa_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Gpgsa__finalize(
                Gpgsa_* self);

            NDDSUSERDllExport
            void Gpgsa__finalize_ex(
                Gpgsa_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Gpgsa__finalize_w_params(
                Gpgsa_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Gpgsa__finalize_optional_members(
                Gpgsa_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Gpgsa__copy(
                Gpgsa_* dst,
                const Gpgsa_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* Gpgsa_ */

