

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Sentence_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef Sentence__1368529434_h
#define Sentence__1368529434_h

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "std_msgs/msg/dds_connext/Header_.h"
namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            extern const char *Sentence_TYPENAME;

            struct Sentence_Seq;
            #ifndef NDDS_STANDALONE_TYPE
            class Sentence_TypeSupport;
            class Sentence_DataWriter;
            class Sentence_DataReader;
            #endif

            class Sentence_ 
            {
              public:
                typedef struct Sentence_Seq Seq;
                #ifndef NDDS_STANDALONE_TYPE
                typedef Sentence_TypeSupport TypeSupport;
                typedef Sentence_DataWriter DataWriter;
                typedef Sentence_DataReader DataReader;
                #endif

                std_msgs::msg::dds_::Header_   header_ ;
                DDS_Char *   sentence_ ;

            };
            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, start exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport __declspec(dllexport)
            #endif

            NDDSUSERDllExport DDS_TypeCode* Sentence__get_typecode(void); /* Type code */

            DDS_SEQUENCE(Sentence_Seq, Sentence_);

            NDDSUSERDllExport
            RTIBool Sentence__initialize(
                Sentence_* self);

            NDDSUSERDllExport
            RTIBool Sentence__initialize_ex(
                Sentence_* self,RTIBool allocatePointers,RTIBool allocateMemory);

            NDDSUSERDllExport
            RTIBool Sentence__initialize_w_params(
                Sentence_* self,
                const struct DDS_TypeAllocationParams_t * allocParams);  

            NDDSUSERDllExport
            void Sentence__finalize(
                Sentence_* self);

            NDDSUSERDllExport
            void Sentence__finalize_ex(
                Sentence_* self,RTIBool deletePointers);

            NDDSUSERDllExport
            void Sentence__finalize_w_params(
                Sentence_* self,
                const struct DDS_TypeDeallocationParams_t * deallocParams);

            NDDSUSERDllExport
            void Sentence__finalize_optional_members(
                Sentence_* self, RTIBool deletePointers);  

            NDDSUSERDllExport
            RTIBool Sentence__copy(
                Sentence_* dst,
                const Sentence_* src);

            #if (defined(RTI_WIN32) || defined (RTI_WINCE)) && defined(NDDS_USER_DLL_EXPORT)
            /* If the code is building on Windows, stop exporting symbols.
            */
            #undef NDDSUSERDllExport
            #define NDDSUSERDllExport
            #endif
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

#endif /* Sentence_ */

