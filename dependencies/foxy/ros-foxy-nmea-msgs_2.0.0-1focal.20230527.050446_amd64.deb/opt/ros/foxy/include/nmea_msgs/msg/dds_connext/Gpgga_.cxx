

/*
WARNING: THIS FILE IS AUTO-GENERATED. DO NOT MODIFY.

This file was generated from Gpgga_.idl using "rtiddsgen".
The rtiddsgen tool is part of the RTI Connext distribution.
For more information, type 'rtiddsgen -help' at a command shell
or consult the RTI Connext manual.
*/

#ifndef NDDS_STANDALONE_TYPE
#ifndef ndds_cpp_h
#include "ndds/ndds_cpp.h"
#endif
#ifndef dds_c_log_impl_h              
#include "dds_c/dds_c_log_impl.h"                                
#endif        

#ifndef cdr_type_h
#include "cdr/cdr_type.h"
#endif    

#ifndef osapi_heap_h
#include "osapi/osapi_heap.h" 
#endif
#else
#include "ndds_standalone_type.h"
#endif

#include "Gpgga_.h"

#include <new>

namespace nmea_msgs {
    namespace msg {
        namespace dds_ {

            /* ========================================================================= */
            const char *Gpgga_TYPENAME = "nmea_msgs::msg::dds_::Gpgga_";

            DDS_TypeCode* Gpgga__get_typecode()
            {
                static RTIBool is_initialized = RTI_FALSE;

                static DDS_TypeCode Gpgga__g_tc_message_id__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gpgga__g_tc_lat_dir__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gpgga__g_tc_lon_dir__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gpgga__g_tc_altitude_units__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gpgga__g_tc_undulation_units__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode Gpgga__g_tc_station_id__string = DDS_INITIALIZE_STRING_TYPECODE(RTI_INT32_MAX);
                static DDS_TypeCode_Member Gpgga__g_tc_members[16]=
                {

                    {
                        (char *)"header_",/* Member name */
                        {
                            0,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"message_id_",/* Member name */
                        {
                            1,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"utc_seconds_",/* Member name */
                        {
                            2,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lat_",/* Member name */
                        {
                            3,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lon_",/* Member name */
                        {
                            4,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lat_dir_",/* Member name */
                        {
                            5,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"lon_dir_",/* Member name */
                        {
                            6,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"gps_qual_",/* Member name */
                        {
                            7,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"num_sats_",/* Member name */
                        {
                            8,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"hdop_",/* Member name */
                        {
                            9,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"alt_",/* Member name */
                        {
                            10,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"altitude_units_",/* Member name */
                        {
                            11,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"undulation_",/* Member name */
                        {
                            12,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"undulation_units_",/* Member name */
                        {
                            13,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"diff_age_",/* Member name */
                        {
                            14,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }, 
                    {
                        (char *)"station_id_",/* Member name */
                        {
                            15,/* Representation ID */          
                            DDS_BOOLEAN_FALSE,/* Is a pointer? */
                            -1, /* Bitfield bits */
                            NULL/* Member type code is assigned later */
                        },
                        0, /* Ignored */
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        RTI_CDR_REQUIRED_MEMBER, /* Is a key? */
                        DDS_PUBLIC_MEMBER,/* Member visibility */
                        1,
                        NULL/* Ignored */
                    }
                };

                static DDS_TypeCode Gpgga__g_tc =
                {{
                        DDS_TK_STRUCT,/* Kind */
                        DDS_BOOLEAN_FALSE, /* Ignored */
                        -1, /*Ignored*/
                        (char *)"nmea_msgs::msg::dds_::Gpgga_", /* Name */
                        NULL, /* Ignored */      
                        0, /* Ignored */
                        0, /* Ignored */
                        NULL, /* Ignored */
                        16, /* Number of members */
                        Gpgga__g_tc_members, /* Members */
                        DDS_VM_NONE  /* Ignored */         
                    }}; /* Type code for Gpgga_*/

                if (is_initialized) {
                    return &Gpgga__g_tc;
                }

                Gpgga__g_tc_members[0]._representation._typeCode = (RTICdrTypeCode *)std_msgs::msg::dds_::Header__get_typecode();

                Gpgga__g_tc_members[1]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_message_id__string;

                Gpgga__g_tc_members[2]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gpgga__g_tc_members[3]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gpgga__g_tc_members[4]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_double;

                Gpgga__g_tc_members[5]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_lat_dir__string;

                Gpgga__g_tc_members[6]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_lon_dir__string;

                Gpgga__g_tc_members[7]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ulong;

                Gpgga__g_tc_members[8]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ulong;

                Gpgga__g_tc_members[9]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gpgga__g_tc_members[10]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gpgga__g_tc_members[11]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_altitude_units__string;

                Gpgga__g_tc_members[12]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_float;

                Gpgga__g_tc_members[13]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_undulation_units__string;

                Gpgga__g_tc_members[14]._representation._typeCode = (RTICdrTypeCode *)&DDS_g_tc_ulong;

                Gpgga__g_tc_members[15]._representation._typeCode = (RTICdrTypeCode *)&Gpgga__g_tc_station_id__string;

                is_initialized = RTI_TRUE;

                return &Gpgga__g_tc;
            }

            RTIBool Gpgga__initialize(
                Gpgga_* sample) {
                return nmea_msgs::msg::dds_::Gpgga__initialize_ex(sample,RTI_TRUE,RTI_TRUE);
            }

            RTIBool Gpgga__initialize_ex(
                Gpgga_* sample,RTIBool allocatePointers, RTIBool allocateMemory)
            {

                struct DDS_TypeAllocationParams_t allocParams =
                DDS_TYPE_ALLOCATION_PARAMS_DEFAULT;

                allocParams.allocate_pointers =  (DDS_Boolean)allocatePointers;
                allocParams.allocate_memory = (DDS_Boolean)allocateMemory;

                return nmea_msgs::msg::dds_::Gpgga__initialize_w_params(
                    sample,&allocParams);

            }

            RTIBool Gpgga__initialize_w_params(
                Gpgga_* sample, const struct DDS_TypeAllocationParams_t * allocParams)
            {

                if (sample == NULL) {
                    return RTI_FALSE;
                }
                if (allocParams == NULL) {
                    return RTI_FALSE;
                }

                if (!std_msgs::msg::dds_::Header__initialize_w_params(&sample->header_,
                allocParams)) {
                    return RTI_FALSE;
                }
                if (allocParams->allocate_memory){
                    sample->message_id_= DDS_String_alloc ((0));
                    if (sample->message_id_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->message_id_!= NULL) { 
                        sample->message_id_[0] = '\0';
                    }
                }

                if (!RTICdrType_initDouble(&sample->utc_seconds_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initDouble(&sample->lat_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initDouble(&sample->lon_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->lat_dir_= DDS_String_alloc ((0));
                    if (sample->lat_dir_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->lat_dir_!= NULL) { 
                        sample->lat_dir_[0] = '\0';
                    }
                }

                if (allocParams->allocate_memory){
                    sample->lon_dir_= DDS_String_alloc ((0));
                    if (sample->lon_dir_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->lon_dir_!= NULL) { 
                        sample->lon_dir_[0] = '\0';
                    }
                }

                if (!RTICdrType_initUnsignedLong(&sample->gps_qual_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initUnsignedLong(&sample->num_sats_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initFloat(&sample->hdop_)) {
                    return RTI_FALSE;
                }

                if (!RTICdrType_initFloat(&sample->alt_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->altitude_units_= DDS_String_alloc ((0));
                    if (sample->altitude_units_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->altitude_units_!= NULL) { 
                        sample->altitude_units_[0] = '\0';
                    }
                }

                if (!RTICdrType_initFloat(&sample->undulation_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->undulation_units_= DDS_String_alloc ((0));
                    if (sample->undulation_units_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->undulation_units_!= NULL) { 
                        sample->undulation_units_[0] = '\0';
                    }
                }

                if (!RTICdrType_initUnsignedLong(&sample->diff_age_)) {
                    return RTI_FALSE;
                }

                if (allocParams->allocate_memory){
                    sample->station_id_= DDS_String_alloc ((0));
                    if (sample->station_id_ == NULL) {
                        return RTI_FALSE;
                    }

                } else {
                    if (sample->station_id_!= NULL) { 
                        sample->station_id_[0] = '\0';
                    }
                }

                return RTI_TRUE;
            }

            void Gpgga__finalize(
                Gpgga_* sample)
            {

                nmea_msgs::msg::dds_::Gpgga__finalize_ex(sample,RTI_TRUE);
            }

            void Gpgga__finalize_ex(
                Gpgga_* sample,RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParams =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;

                if (sample==NULL) {
                    return;
                } 

                deallocParams.delete_pointers = (DDS_Boolean)deletePointers;

                nmea_msgs::msg::dds_::Gpgga__finalize_w_params(
                    sample,&deallocParams);
            }

            void Gpgga__finalize_w_params(
                Gpgga_* sample,const struct DDS_TypeDeallocationParams_t * deallocParams)
            {

                if (sample==NULL) {
                    return;
                }

                if (deallocParams == NULL) {
                    return;
                }

                std_msgs::msg::dds_::Header__finalize_w_params(&sample->header_,deallocParams);

                if (sample->message_id_ != NULL) {
                    DDS_String_free(sample->message_id_);
                    sample->message_id_=NULL;

                }

                if (sample->lat_dir_ != NULL) {
                    DDS_String_free(sample->lat_dir_);
                    sample->lat_dir_=NULL;

                }
                if (sample->lon_dir_ != NULL) {
                    DDS_String_free(sample->lon_dir_);
                    sample->lon_dir_=NULL;

                }

                if (sample->altitude_units_ != NULL) {
                    DDS_String_free(sample->altitude_units_);
                    sample->altitude_units_=NULL;

                }

                if (sample->undulation_units_ != NULL) {
                    DDS_String_free(sample->undulation_units_);
                    sample->undulation_units_=NULL;

                }

                if (sample->station_id_ != NULL) {
                    DDS_String_free(sample->station_id_);
                    sample->station_id_=NULL;

                }
            }

            void Gpgga__finalize_optional_members(
                Gpgga_* sample, RTIBool deletePointers)
            {
                struct DDS_TypeDeallocationParams_t deallocParamsTmp =
                DDS_TYPE_DEALLOCATION_PARAMS_DEFAULT;
                struct DDS_TypeDeallocationParams_t * deallocParams =
                &deallocParamsTmp;

                if (sample==NULL) {
                    return;
                } 
                if (deallocParams) {} /* To avoid warnings */

                deallocParamsTmp.delete_pointers = (DDS_Boolean)deletePointers;
                deallocParamsTmp.delete_optional_members = DDS_BOOLEAN_TRUE;

                std_msgs::msg::dds_::Header__finalize_optional_members(&sample->header_, deallocParams->delete_pointers);
            }

            RTIBool Gpgga__copy(
                Gpgga_* dst,
                const Gpgga_* src)
            {
                try {

                    if (dst == NULL || src == NULL) {
                        return RTI_FALSE;
                    }

                    if (!std_msgs::msg::dds_::Header__copy(
                        &dst->header_,(const std_msgs::msg::dds_::Header_*)&src->header_)) {
                        return RTI_FALSE;
                    } 
                    if (!RTICdrType_copyStringEx (
                        &dst->message_id_, src->message_id_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->utc_seconds_, &src->utc_seconds_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->lat_, &src->lat_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyDouble (
                        &dst->lon_, &src->lon_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->lat_dir_, src->lat_dir_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->lon_dir_, src->lon_dir_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedLong (
                        &dst->gps_qual_, &src->gps_qual_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedLong (
                        &dst->num_sats_, &src->num_sats_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->hdop_, &src->hdop_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->alt_, &src->alt_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->altitude_units_, src->altitude_units_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyFloat (
                        &dst->undulation_, &src->undulation_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->undulation_units_, src->undulation_units_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyUnsignedLong (
                        &dst->diff_age_, &src->diff_age_)) { 
                        return RTI_FALSE;
                    }
                    if (!RTICdrType_copyStringEx (
                        &dst->station_id_, src->station_id_, 
                        (RTI_INT32_MAX-1) + 1,RTI_TRUE)){
                        return RTI_FALSE;
                    }

                    return RTI_TRUE;

                } catch (std::bad_alloc&) {
                    return RTI_FALSE;
                }
            }

            /**
            * <<IMPLEMENTATION>>
            *
            * Defines:  TSeq, T
            *
            * Configure and implement 'Gpgga_' sequence class.
            */
            #define T Gpgga_
            #define TSeq Gpgga_Seq

            #define T_initialize_w_params nmea_msgs::msg::dds_::Gpgga__initialize_w_params

            #define T_finalize_w_params   nmea_msgs::msg::dds_::Gpgga__finalize_w_params
            #define T_copy       nmea_msgs::msg::dds_::Gpgga__copy

            #ifndef NDDS_STANDALONE_TYPE
            #include "dds_c/generic/dds_c_sequence_TSeq.gen"
            #include "dds_cpp/generic/dds_cpp_sequence_TSeq.gen"
            #else
            #include "dds_c_sequence_TSeq.gen"
            #include "dds_cpp_sequence_TSeq.gen"
            #endif

            #undef T_copy
            #undef T_finalize_w_params

            #undef T_initialize_w_params

            #undef TSeq
            #undef T
        } /* namespace dds_  */
    } /* namespace msg  */
} /* namespace nmea_msgs  */

