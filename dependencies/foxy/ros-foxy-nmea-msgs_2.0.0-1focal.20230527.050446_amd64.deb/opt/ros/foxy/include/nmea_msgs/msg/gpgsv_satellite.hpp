// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPGSV_SATELLITE_HPP_
#define NMEA_MSGS__MSG__GPGSV_SATELLITE_HPP_

#include "nmea_msgs/msg/detail/gpgsv_satellite__struct.hpp"
#include "nmea_msgs/msg/detail/gpgsv_satellite__builder.hpp"
#include "nmea_msgs/msg/detail/gpgsv_satellite__traits.hpp"
#include "nmea_msgs/msg/detail/gpgsv_satellite__type_support.hpp"

#endif  // NMEA_MSGS__MSG__GPGSV_SATELLITE_HPP_
