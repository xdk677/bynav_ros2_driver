// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from gps_msgs:msg/GPSFix.idl
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__DETAIL__GPS_FIX__STRUCT_H_
#define GPS_MSGS__MSG__DETAIL__GPS_FIX__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'COVARIANCE_TYPE_UNKNOWN'.
enum
{
  gps_msgs__msg__GPSFix__COVARIANCE_TYPE_UNKNOWN = 0
};

/// Constant 'COVARIANCE_TYPE_APPROXIMATED'.
enum
{
  gps_msgs__msg__GPSFix__COVARIANCE_TYPE_APPROXIMATED = 1
};

/// Constant 'COVARIANCE_TYPE_DIAGONAL_KNOWN'.
enum
{
  gps_msgs__msg__GPSFix__COVARIANCE_TYPE_DIAGONAL_KNOWN = 2
};

/// Constant 'COVARIANCE_TYPE_KNOWN'.
enum
{
  gps_msgs__msg__GPSFix__COVARIANCE_TYPE_KNOWN = 3
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'status'
#include "gps_msgs/msg/detail/gps_status__struct.h"

// Struct defined in msg/GPSFix in the package gps_msgs.
typedef struct gps_msgs__msg__GPSFix
{
  std_msgs__msg__Header header;
  gps_msgs__msg__GPSStatus status;
  double latitude;
  double longitude;
  double altitude;
  double track;
  double speed;
  double climb;
  double pitch;
  double roll;
  double dip;
  double time;
  double gdop;
  double pdop;
  double hdop;
  double vdop;
  double tdop;
  double err;
  double err_horz;
  double err_vert;
  double err_track;
  double err_speed;
  double err_climb;
  double err_time;
  double err_pitch;
  double err_roll;
  double err_dip;
  double position_covariance[9];
  uint8_t position_covariance_type;
} gps_msgs__msg__GPSFix;

// Struct for a sequence of gps_msgs__msg__GPSFix.
typedef struct gps_msgs__msg__GPSFix__Sequence
{
  gps_msgs__msg__GPSFix * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} gps_msgs__msg__GPSFix__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // GPS_MSGS__MSG__DETAIL__GPS_FIX__STRUCT_H_
