// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from gps_msgs:msg/GPSFix.idl
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__DETAIL__GPS_FIX__TRAITS_HPP_
#define GPS_MSGS__MSG__DETAIL__GPS_FIX__TRAITS_HPP_

#include "gps_msgs/msg/detail/gps_fix__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"
// Member 'status'
#include "gps_msgs/msg/detail/gps_status__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const gps_msgs::msg::GPSFix & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_yaml(msg.header, out, indentation + 2);
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status:\n";
    to_yaml(msg.status, out, indentation + 2);
  }

  // member: latitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "latitude: ";
    value_to_yaml(msg.latitude, out);
    out << "\n";
  }

  // member: longitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "longitude: ";
    value_to_yaml(msg.longitude, out);
    out << "\n";
  }

  // member: altitude
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "altitude: ";
    value_to_yaml(msg.altitude, out);
    out << "\n";
  }

  // member: track
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "track: ";
    value_to_yaml(msg.track, out);
    out << "\n";
  }

  // member: speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "speed: ";
    value_to_yaml(msg.speed, out);
    out << "\n";
  }

  // member: climb
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "climb: ";
    value_to_yaml(msg.climb, out);
    out << "\n";
  }

  // member: pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pitch: ";
    value_to_yaml(msg.pitch, out);
    out << "\n";
  }

  // member: roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "roll: ";
    value_to_yaml(msg.roll, out);
    out << "\n";
  }

  // member: dip
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "dip: ";
    value_to_yaml(msg.dip, out);
    out << "\n";
  }

  // member: time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "time: ";
    value_to_yaml(msg.time, out);
    out << "\n";
  }

  // member: gdop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "gdop: ";
    value_to_yaml(msg.gdop, out);
    out << "\n";
  }

  // member: pdop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pdop: ";
    value_to_yaml(msg.pdop, out);
    out << "\n";
  }

  // member: hdop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "hdop: ";
    value_to_yaml(msg.hdop, out);
    out << "\n";
  }

  // member: vdop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "vdop: ";
    value_to_yaml(msg.vdop, out);
    out << "\n";
  }

  // member: tdop
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tdop: ";
    value_to_yaml(msg.tdop, out);
    out << "\n";
  }

  // member: err
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err: ";
    value_to_yaml(msg.err, out);
    out << "\n";
  }

  // member: err_horz
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_horz: ";
    value_to_yaml(msg.err_horz, out);
    out << "\n";
  }

  // member: err_vert
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_vert: ";
    value_to_yaml(msg.err_vert, out);
    out << "\n";
  }

  // member: err_track
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_track: ";
    value_to_yaml(msg.err_track, out);
    out << "\n";
  }

  // member: err_speed
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_speed: ";
    value_to_yaml(msg.err_speed, out);
    out << "\n";
  }

  // member: err_climb
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_climb: ";
    value_to_yaml(msg.err_climb, out);
    out << "\n";
  }

  // member: err_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_time: ";
    value_to_yaml(msg.err_time, out);
    out << "\n";
  }

  // member: err_pitch
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_pitch: ";
    value_to_yaml(msg.err_pitch, out);
    out << "\n";
  }

  // member: err_roll
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_roll: ";
    value_to_yaml(msg.err_roll, out);
    out << "\n";
  }

  // member: err_dip
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "err_dip: ";
    value_to_yaml(msg.err_dip, out);
    out << "\n";
  }

  // member: position_covariance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.position_covariance.size() == 0) {
      out << "position_covariance: []\n";
    } else {
      out << "position_covariance:\n";
      for (auto item : msg.position_covariance) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: position_covariance_type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_covariance_type: ";
    value_to_yaml(msg.position_covariance_type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const gps_msgs::msg::GPSFix & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<gps_msgs::msg::GPSFix>()
{
  return "gps_msgs::msg::GPSFix";
}

template<>
inline const char * name<gps_msgs::msg::GPSFix>()
{
  return "gps_msgs/msg/GPSFix";
}

template<>
struct has_fixed_size<gps_msgs::msg::GPSFix>
  : std::integral_constant<bool, has_fixed_size<gps_msgs::msg::GPSStatus>::value && has_fixed_size<std_msgs::msg::Header>::value> {};

template<>
struct has_bounded_size<gps_msgs::msg::GPSFix>
  : std::integral_constant<bool, has_bounded_size<gps_msgs::msg::GPSStatus>::value && has_bounded_size<std_msgs::msg::Header>::value> {};

template<>
struct is_message<gps_msgs::msg::GPSFix>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // GPS_MSGS__MSG__DETAIL__GPS_FIX__TRAITS_HPP_
