// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from gps_msgs:msg/GPSStatus.idl
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__DETAIL__GPS_STATUS__TRAITS_HPP_
#define GPS_MSGS__MSG__DETAIL__GPS_STATUS__TRAITS_HPP_

#include "gps_msgs/msg/detail/gps_status__struct.hpp"
#include <stdint.h>
#include <rosidl_runtime_cpp/traits.hpp>
#include <sstream>
#include <string>
#include <type_traits>

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace rosidl_generator_traits
{

inline void to_yaml(
  const gps_msgs::msg::GPSStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_yaml(msg.header, out, indentation + 2);
  }

  // member: satellites_used
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "satellites_used: ";
    value_to_yaml(msg.satellites_used, out);
    out << "\n";
  }

  // member: satellite_used_prn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.satellite_used_prn.size() == 0) {
      out << "satellite_used_prn: []\n";
    } else {
      out << "satellite_used_prn:\n";
      for (auto item : msg.satellite_used_prn) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: satellites_visible
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "satellites_visible: ";
    value_to_yaml(msg.satellites_visible, out);
    out << "\n";
  }

  // member: satellite_visible_prn
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.satellite_visible_prn.size() == 0) {
      out << "satellite_visible_prn: []\n";
    } else {
      out << "satellite_visible_prn:\n";
      for (auto item : msg.satellite_visible_prn) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: satellite_visible_z
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.satellite_visible_z.size() == 0) {
      out << "satellite_visible_z: []\n";
    } else {
      out << "satellite_visible_z:\n";
      for (auto item : msg.satellite_visible_z) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: satellite_visible_azimuth
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.satellite_visible_azimuth.size() == 0) {
      out << "satellite_visible_azimuth: []\n";
    } else {
      out << "satellite_visible_azimuth:\n";
      for (auto item : msg.satellite_visible_azimuth) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: satellite_visible_snr
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.satellite_visible_snr.size() == 0) {
      out << "satellite_visible_snr: []\n";
    } else {
      out << "satellite_visible_snr:\n";
      for (auto item : msg.satellite_visible_snr) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    value_to_yaml(msg.status, out);
    out << "\n";
  }

  // member: motion_source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "motion_source: ";
    value_to_yaml(msg.motion_source, out);
    out << "\n";
  }

  // member: orientation_source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "orientation_source: ";
    value_to_yaml(msg.orientation_source, out);
    out << "\n";
  }

  // member: position_source
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "position_source: ";
    value_to_yaml(msg.position_source, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const gps_msgs::msg::GPSStatus & msg)
{
  std::ostringstream out;
  to_yaml(msg, out);
  return out.str();
}

template<>
inline const char * data_type<gps_msgs::msg::GPSStatus>()
{
  return "gps_msgs::msg::GPSStatus";
}

template<>
inline const char * name<gps_msgs::msg::GPSStatus>()
{
  return "gps_msgs/msg/GPSStatus";
}

template<>
struct has_fixed_size<gps_msgs::msg::GPSStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<gps_msgs::msg::GPSStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<gps_msgs::msg::GPSStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // GPS_MSGS__MSG__DETAIL__GPS_STATUS__TRAITS_HPP_
