// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from gps_msgs:msg/GPSStatus.idl
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__DETAIL__GPS_STATUS__STRUCT_H_
#define GPS_MSGS__MSG__DETAIL__GPS_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'STATUS_NO_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_NO_FIX = -1
};

/// Constant 'STATUS_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_FIX = 0
};

/// Constant 'STATUS_SBAS_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_SBAS_FIX = 1
};

/// Constant 'STATUS_GBAS_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_GBAS_FIX = 2
};

/// Constant 'STATUS_DGPS_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_DGPS_FIX = 18
};

/// Constant 'STATUS_WAAS_FIX'.
enum
{
  gps_msgs__msg__GPSStatus__STATUS_WAAS_FIX = 33
};

/// Constant 'SOURCE_NONE'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_NONE = 0
};

/// Constant 'SOURCE_GPS'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_GPS = 1
};

/// Constant 'SOURCE_POINTS'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_POINTS = 2
};

/// Constant 'SOURCE_DOPPLER'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_DOPPLER = 4
};

/// Constant 'SOURCE_ALTIMETER'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_ALTIMETER = 8
};

/// Constant 'SOURCE_MAGNETIC'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_MAGNETIC = 16
};

/// Constant 'SOURCE_GYRO'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_GYRO = 32
};

/// Constant 'SOURCE_ACCEL'.
enum
{
  gps_msgs__msg__GPSStatus__SOURCE_ACCEL = 64
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'satellite_used_prn'
// Member 'satellite_visible_prn'
// Member 'satellite_visible_z'
// Member 'satellite_visible_azimuth'
// Member 'satellite_visible_snr'
#include "rosidl_runtime_c/primitives_sequence.h"

// Struct defined in msg/GPSStatus in the package gps_msgs.
typedef struct gps_msgs__msg__GPSStatus
{
  std_msgs__msg__Header header;
  uint16_t satellites_used;
  rosidl_runtime_c__int32__Sequence satellite_used_prn;
  uint16_t satellites_visible;
  rosidl_runtime_c__int32__Sequence satellite_visible_prn;
  rosidl_runtime_c__int32__Sequence satellite_visible_z;
  rosidl_runtime_c__int32__Sequence satellite_visible_azimuth;
  rosidl_runtime_c__int32__Sequence satellite_visible_snr;
  int16_t status;
  uint16_t motion_source;
  uint16_t orientation_source;
  uint16_t position_source;
} gps_msgs__msg__GPSStatus;

// Struct for a sequence of gps_msgs__msg__GPSStatus.
typedef struct gps_msgs__msg__GPSStatus__Sequence
{
  gps_msgs__msg__GPSStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} gps_msgs__msg__GPSStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // GPS_MSGS__MSG__DETAIL__GPS_STATUS__STRUCT_H_
