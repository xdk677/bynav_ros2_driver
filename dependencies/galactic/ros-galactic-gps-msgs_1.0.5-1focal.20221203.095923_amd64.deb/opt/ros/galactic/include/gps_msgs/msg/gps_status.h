// generated from rosidl_generator_c/resource/idl.h.em
// with input from gps_msgs:msg/GPSStatus.idl
// generated code does not contain a copyright notice

#ifndef GPS_MSGS__MSG__GPS_STATUS_H_
#define GPS_MSGS__MSG__GPS_STATUS_H_

#include "gps_msgs/msg/detail/gps_status__struct.h"
#include "gps_msgs/msg/detail/gps_status__functions.h"
#include "gps_msgs/msg/detail/gps_status__type_support.h"

#endif  // GPS_MSGS__MSG__GPS_STATUS_H_
