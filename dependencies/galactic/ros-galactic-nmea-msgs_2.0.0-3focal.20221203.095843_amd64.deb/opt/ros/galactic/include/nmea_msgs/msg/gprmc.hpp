// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPRMC_HPP_
#define NMEA_MSGS__MSG__GPRMC_HPP_

#include "nmea_msgs/msg/detail/gprmc__struct.hpp"
#include "nmea_msgs/msg/detail/gprmc__builder.hpp"
#include "nmea_msgs/msg/detail/gprmc__traits.hpp"

#endif  // NMEA_MSGS__MSG__GPRMC_HPP_
