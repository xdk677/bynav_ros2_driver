// generated from rosidl_generator_c/resource/idl.h.em
// with input from nmea_msgs:msg/Gpgsa.idl
// generated code does not contain a copyright notice

#ifndef NMEA_MSGS__MSG__GPGSA_H_
#define NMEA_MSGS__MSG__GPGSA_H_

#include "nmea_msgs/msg/detail/gpgsa__struct.h"
#include "nmea_msgs/msg/detail/gpgsa__functions.h"
#include "nmea_msgs/msg/detail/gpgsa__type_support.h"

#endif  // NMEA_MSGS__MSG__GPGSA_H_
